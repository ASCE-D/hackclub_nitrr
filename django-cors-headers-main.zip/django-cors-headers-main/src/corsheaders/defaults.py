from __future__ import annotations

default_headers = (
    "accept",
    "accept-encoding",
    "authorization",
    "content-type",
    "dnt",
    "origin",
    "user-agent",
    "x-csrftoken",
    "x-requested-with",
)

default_methods = ("DELETE", "GET", "OPTIONS", "PATCH", "POST", "PUT")
